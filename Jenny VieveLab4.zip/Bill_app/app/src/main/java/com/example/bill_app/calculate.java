package com.example.bill_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class calculate extends AppCompatActivity {
    int numbers;
    double bill;
    double tip;
    double split1;
    double total;
    String rate1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        final EditText split = (EditText) findViewById(R.id.billP);
        final EditText number = (EditText) findViewById(R.id.txtN);
        Spinner rate = (Spinner) findViewById(R.id.spinner);
        Button button = (Button) findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            TextView result = (TextView) findViewById(R.id.txtResults);
            @Override
            public void onClick(View v) {
                bill = Integer.parseInt(split.getText().toString());
                numbers = Integer.parseInt(number.getText().toString());
                tip = bill * .18 ;
                split1 = bill / numbers;
                total = split1 + tip;
                DecimalFormat currency = new DecimalFormat("Php ###,###.##");
                rate1 = rate.getSelectedItem().toString();
                result.setText("Split Every Person Is: " + currency.format(total) + " With 18% Tip");


            }
        });
    }
}